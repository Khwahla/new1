package ae.emiratesid.toolkit.sample.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.security.Key;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.Iterator;

import javax.xml.crypto.AlgorithmMethod;
import javax.xml.crypto.KeySelector;
import javax.xml.crypto.KeySelectorException;
import javax.xml.crypto.KeySelectorResult;
import javax.xml.crypto.XMLCryptoContext;
import javax.xml.crypto.XMLStructure;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignatureMethod;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.io.IOUtils;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ae.emiratesid.toolkit.sample.exception.ToolkitException;
import sun.security.x509.X509CertImpl;

public class XmlUtils {
	
	
	public static ArrayList<String> parseRequestID(String xmlPath , String...elements){

        try {
            File inputFile = new File(xmlPath);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
            NodeList nList = doc.getElementsByTagName("Header");
            System.out.println("----------------------------"+nList.getLength());
//            parseHeader(nList);
            return fetchRequestID(nList , elements);
        } catch (Exception e) {
            e.printStackTrace();
        }//catch()
        return null;

    }//parseVerifyPinXml()
	private static ArrayList<String> fetchRequestID(NodeList nList , String...elements) {
		ArrayList<String> values =  new ArrayList<>();
        for (int temp = 0; temp < nList.getLength(); temp++) {
            Node nNode = nList.item(temp);
            System.out.println("\nCurrent Element :" + nNode.getNodeName());

            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) nNode;
                
                for(int j =  0 ; j<elements.length ; j++){
                	System.out.println("RequestID : "
                            + eElement
                            .getElementsByTagName(elements[j])
                            .item(0)
                            .getTextContent());
                    values.add( eElement
                            .getElementsByTagName(elements[j])
                            .item(0)
                            .getTextContent());
                }//
                
            }
        }//for()
        return values;
    }//parseHeader()
	
	public static boolean verifySignature(String path) throws Exception {

        File inputFile = new File(path);
        // Instantiate the document to be validated
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        Document doc = dbf.newDocumentBuilder().parse(
                new FileInputStream(inputFile));

        // Find Signature element
        NodeList nl = doc.getElementsByTagNameNS(XMLSignature.XMLNS,
                "Signature");
        if (nl.getLength() == 0) {
            throw new Exception("Cannot find Signature element");
        }

        // Create a DOM XMLSignatureFactory that will be used to unmarshal the
        // document containing the XMLSignature
        XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM");

        // Create a DOMValidateContext and specify a KeyValue KeySelector
        // and document context
        DOMValidateContext valContext = new DOMValidateContext(
                new X509KeySelector(), nl.item(0));

        // unmarshal the XMLSignature
        XMLSignature signature = fac.unmarshalXMLSignature(valContext);

        // Validate the XMLSignature (generated above)
        boolean coreValidity = signature.validate(valContext);

        // Check core validation status
        if (coreValidity == false) {
            System.err.println("Signature failed core validation");
            boolean sv = signature.getSignatureValue().validate(valContext);
            System.out.println("signature validation status: " + sv);
            // check the validation status of each Reference
            Iterator<?> i = signature.getSignedInfo().getReferences().iterator();
            for (int j = 0; i.hasNext(); j++) {
                boolean refValid = ((Reference) i.next()).validate(valContext);
                System.out.println("ref[" + j + "] validity status: "
                        + refValid);
            }
        } else {
            System.out.println("Signature passed core validation");
            return true;
        }
       return false;
    }//


    private static class X509KeySelector extends KeySelector {
        public KeySelectorResult select(KeyInfo keyInfo,
                                        KeySelector.Purpose purpose,
                                        AlgorithmMethod method,
                                        XMLCryptoContext context)
                throws KeySelectorException {
            Iterator ki = keyInfo.getContent().iterator();
            while (ki.hasNext()) {
                XMLStructure info = (XMLStructure) ki.next();
                if (!(info instanceof X509Data)) {
                    System.out.println("Not an instance of X509Data");
                continue;
                }//if()

                X509Data x509Data = (X509Data) info;
                Iterator xi = x509Data.getContent().iterator();
                System.out.println(" XI length " + x509Data.getContent().size());
                while (xi.hasNext()) {
                    System.out.println("Xi is iterating.");
                    Object o = xi.next();
                    if (!(o instanceof X509CertImpl)) {
                        System.out.println("Class " + o.getClass().toString());
                        continue;
                    }
                    final PublicKey key = ((X509CertImpl)o).getPublicKey();
                    System.out.println("Issuer Name" + ((X509CertImpl)o).getIssuerDN());
                    // Make sure the algorithm is compatible
                    // with the method.
                    System.out.println("public key found");
                    System.out.println("method Algorithm " + method.getAlgorithm());
                    System.out.println("key  Algorithm " +key.getAlgorithm());
                    if (algEquals(method.getAlgorithm(), key.getAlgorithm())) {
                        return new KeySelectorResult() {
                            public Key getKey() { return key; }
                        };
                    }
                }
            }
            throw new KeySelectorException("No key found!");
        }

        boolean algEquals(String algURI, String algName) {
            if ((algName.equalsIgnoreCase("DSA") &&
                    algURI.equalsIgnoreCase(SignatureMethod.DSA_SHA1)) ||
                    (algName.equalsIgnoreCase("RSA") &&
                            algURI.equalsIgnoreCase(SignatureMethod.RSA_SHA1))) {
            	
                return false;
            } else {
                return true;
            }
        }
    }//
    
    public static String writeToFile(String xml) throws ToolkitException{

    	try {
    		FileWriter writer = new FileWriter("response.xml");
    		writer.write(xml);
    		writer.close();
		} catch (Exception e) {
			throw new ToolkitException(e.getMessage());
		}// catch()
		
		return "response.xml";
	}//writeToFile()
    
    public static String validateXMlForRequestHandle(String responseXml , String requestID) throws ToolkitException{

		ArrayList<String> response =  null;
		if(null == responseXml || responseXml.isEmpty()){
			System.out.println("responseXml is null");
			throw new ToolkitException("responseXml is null");
		}//if()
		else{
			String path;
			try {
				path = XmlUtils.writeToFile(responseXml);
				if(!XmlUtils.verifySignature(path)){
					System.out.println("Signature validation failed");
					throw new ToolkitException("Signature validation failed");
				}//if()
				else{
					response=  XmlUtils.parseRequestID(path , "RequestID", "RequestHandle");
					System.out.println(response.get(0) +"  ----" + response.get(1));
					if(response.get(0) != null && response.get(0).equals(requestID)){
						System.out.println("request success");
						return response.get(1);
					}//
					else{
						throw new ToolkitException("RequestID doesn't match");
					}//else
				}//else
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new ToolkitException(e);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new ToolkitException(e);
			}//catch()
		}//else
	}//validateXML()

	public static boolean validateXMlRequestID(String responseXml , String requestID) throws ToolkitException{

		ArrayList<String> response =  null;
		if(null == responseXml || responseXml.isEmpty()){
			System.out.println("responseXml is null");
			throw new ToolkitException("responseXml is null");
		}//if()
		else{
			String path;
			try {
				path = XmlUtils.writeToFile(responseXml);
				if(!XmlUtils.verifySignature(path)){
					System.out.println("Signature validation failed");
					throw new ToolkitException("Signature validation failed");
				}//if()
				else{
					response=  XmlUtils.parseRequestID(path , "RequestID");
					System.out.println(response.get(0) +"  ----" );
					if(response.get(0) != null && response.get(0).equals(requestID)){
						System.out.println("request success");
						return true;
					}//
					else{
						throw new ToolkitException("RequestID doesn't match");
					}//else
				}//else
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new ToolkitException(e);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new ToolkitException(e);
			}//catch()
		}//else
	}//validateXML()


	public static boolean verifyXMLSignature(String xmlFile) throws Exception {

		InputStream inputStream = IOUtils.toInputStream(xmlFile, "UTF-8");
        // Instantiate the document to be validated
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        Document doc = dbf.newDocumentBuilder().parse(
                inputStream);

        // Find Signature element
        NodeList nl = doc.getElementsByTagNameNS(XMLSignature.XMLNS,
                "Signature");
        if (nl.getLength() == 0) {
            throw new Exception("Cannot find Signature element");
        }

        // Create a DOM XMLSignatureFactory that will be used to unmarshal the
        // document containing the XMLSignature
        XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM");

        // Create a DOMValidateContext and specify a KeyValue KeySelector
        // and document context
        DOMValidateContext valContext = new DOMValidateContext(
                new X509KeySelector(), nl.item(0));

        // unmarshal the XMLSignature
        XMLSignature signature = fac.unmarshalXMLSignature(valContext);

        // Validate the XMLSignature (generated above)
        boolean coreValidity = signature.validate(valContext);

        // Check core validation status
        if (coreValidity == false) {
            System.err.println("Signature failed core validation");
            boolean sv = signature.getSignatureValue().validate(valContext);
            System.out.println("signature validation status: " + sv);
            // check the validation status of each Reference
            Iterator<?> i = signature.getSignedInfo().getReferences().iterator();
            for (int j = 0; i.hasNext(); j++) {
                boolean refValid = ((Reference) i.next()).validate(valContext);
                System.out.println("ref[" + j + "] validity status: "
                        + refValid);
            }
        } else {
            System.out.println("Signature passed core validation");
            return true;
        }
       return false;
    }//
	
	public static boolean verifySignature1(String xmlFile) throws Exception {

		InputStream inputStream = IOUtils.toInputStream(xmlFile, "UTF-8");
		
		 DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	        dbf.setNamespaceAware(true);
	        Document doc = dbf.newDocumentBuilder().parse(
	                inputStream);

	        
//		File inputFile = new File(path);
//		// Instantiate the document to be validated
//		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//		dbf.setNamespaceAware(true);
//		Document doc = dbf.newDocumentBuilder().parse(
//				new FileInputStream(inputFile));

		// Find Signature element
		NodeList nl = doc.getElementsByTagNameNS(XMLSignature.XMLNS,
				"Signature");
		if (nl.getLength() == 0) {
			throw new Exception("Cannot find Signature element");
		}

		// Create a DOM XMLSignatureFactory that will be used to unmarshal the
		// document containing the XMLSignature
		XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM");

		// Create a DOMValidateContext and specify a KeyValue KeySelector
		// and document context
		DOMValidateContext valContext = new DOMValidateContext(
				new X509KeySelector(), nl.item(0));

		Element element = (Element)doc.getElementsByTagName("Message").item(0);
		System.out.println(doc.getDocumentElement().getTagName());
		Attr attr = element.getAttributeNode( "xml:id");

		System.out.println(element.getAttributes().item(0));
		element.setIdAttributeNode(attr, true);
		
		XMLSignature signature = fac.unmarshalXMLSignature(valContext);

		// Validate the XMLSignature (generated above)
		boolean coreValidity = signature.validate(valContext);

		// Check core validation status
		if (coreValidity == false) {
			System.out.println("Signature failed core validation");
			boolean sv = signature.getSignatureValue().validate(valContext);
			System.out.println("signature validation status: " + sv);
			// check the validation status of each Reference
			Iterator<?> i = signature.getSignedInfo().getReferences().iterator();
			
			for (int j = 0; i.hasNext(); j++) {
				System.out.println();
				boolean refValid = ((Reference) i.next()).validate(valContext);
				System.out.println("ref[" + j + "] validity status: "
						+ refValid);
			}
		} else {
			System.out.println("Signature passed core validation");
			return true;
		}
		return false;
	}//
}
