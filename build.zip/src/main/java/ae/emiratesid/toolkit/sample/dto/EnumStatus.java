package ae.emiratesid.toolkit.sample.dto;

public enum EnumStatus {

	FAILED,
	SUCCESS

}
