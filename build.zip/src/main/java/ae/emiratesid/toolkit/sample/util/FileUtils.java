package ae.emiratesid.toolkit.sample.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class FileUtils {
	
//	public static String readFileContent(String path) throws IOException{
//		if(path== null ||path.isEmpty()){
//			throw new IllegalArgumentException("Path is null");
//		}//
//		FileInputStream in = new FileInputStream(path);
//		byte[] content =  new byte[in.available()];
//		in.read(content);
//		String contentStr =  new String(content);
//		return contentStr;
//	}
	public static String readFileContent(String path) throws IOException{
		if(path== null ||path.isEmpty()){
			throw new IllegalArgumentException("Path is null");
		}//
		InputStream in = FileUtils.class.getResourceAsStream(path);
		byte[] content =  new byte[in.available()];
		in.read(content);
		String contentStr =  new String(content);
		return contentStr;
	}
	public static String readFileContentFromPath(String path) throws IOException{
		if(path== null || path.isEmpty()){
			throw new IllegalArgumentException("File is invalid");
		}//
		InputStream in = new FileInputStream(path);
		byte[] content =  new byte[in.available()];
		in.read(content);
		String contentStr =  new String(content);
		return contentStr;
	}
	
	public static void writeFile(String path , byte[] data) throws Exception{
		OutputStream out = new FileOutputStream(path);
		out.write(data);
		out.close();
	}
	
	

}
