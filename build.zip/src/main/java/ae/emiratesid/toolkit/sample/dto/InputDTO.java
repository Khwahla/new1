package ae.emiratesid.toolkit.sample.dto;

public class InputDTO {

	private String strXML;
	private String pin;
	private String userName;
	private String password;
	private String requestHandle;
	private String publicKey;
	
	

	public String getPublicKey() {
		return publicKey;
	}

	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}

	public String getRequestHandle() {
		return requestHandle;
	}

	public void setRequestHandle(String requestHandle) {
		this.requestHandle = requestHandle;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public String getStrXML() {
		return strXML;
	}

	public void setStrXML(String strXML) {
		this.strXML = strXML;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UserName:"+getUserName());
		builder.append(" :: ");
		builder.append("Password:"+getPassword());
		builder.append(" :: ");
		builder.append("Pin:"+getPin());
		builder.append(" :: ");
		builder.append("PublicKey:"+getPublicKey());
		builder.append(" :: ");
		builder.append("RequestHandle:"+getRequestHandle());		
		builder.append(" :: ");
		builder.append("StrXML:"+getStrXML());		
		builder.append(" :: ");
		return builder.toString();
	}

}
