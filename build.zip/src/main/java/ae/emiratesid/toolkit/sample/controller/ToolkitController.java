package ae.emiratesid.toolkit.sample.controller;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ae.emiratesid.toolkit.sample.dto.EnumStatus;
import ae.emiratesid.toolkit.sample.dto.InputDTO;
import ae.emiratesid.toolkit.sample.dto.ResultDTO;
import ae.emiratesid.toolkit.sample.exception.ToolkitException;
import ae.emiratesid.toolkit.sample.util.CryptoUtils;
import ae.emiratesid.toolkit.sample.util.ToolkitAssert;
import ae.emiratesid.toolkit.sample.util.XmlUtils;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping(path = "/ToolkitController")
public class ToolkitController {

	private static final Logger logger = Logger.getLogger(ToolkitController.class);

	@RequestMapping(value = "/pki/verify", method = RequestMethod.POST)
	public ResultDTO verifyXMLSign(@RequestBody InputDTO inputDTO) {
		logger.debug("Inside verifyXMLSign()...inputDTO =" + inputDTO);
		ResultDTO dto = null;
		try {

			boolean result = XmlUtils.verifySignature1(inputDTO.getStrXML());
			logger.debug("verifyXMLSign() :: result =" + result);

			dto = new ResultDTO();

			if (result) {
				dto.setStatus(EnumStatus.SUCCESS);
				dto.setMessage("xml verified successfully");
			} else {
				dto.setStatus(EnumStatus.FAILED);
				dto.setMessage("xml verification failed");
			}
		} catch (Exception e) {
			throw new ToolkitException(e.getMessage());
		}

		return dto;
	}

	@RequestMapping(value = "/pki/encrypt", method = RequestMethod.POST)
	public ResultDTO encryptData(@RequestBody InputDTO inputDTO) {
		logger.debug("Inside encryptData()...inputDTO =" + inputDTO);
		ResultDTO dto = null;
		try {

			ToolkitAssert.isNullorEmpty(inputDTO.getUserName(), "UserName");
			ToolkitAssert.isNullorEmpty(inputDTO.getRequestHandle(), "RequestHandle");
			ToolkitAssert.isNullorEmpty(inputDTO.getPublicKey(), "publicKey");
			CryptoUtils cryptoUtils = new CryptoUtils();
			String result = cryptoUtils.encryptParams(inputDTO.getUserName(), inputDTO.getRequestHandle(),
					inputDTO.getPublicKey());

			dto = new ResultDTO();

			dto.setStatus(EnumStatus.SUCCESS);
			dto.setMessage(result);

		} catch (Exception e) {
			throw new ToolkitException(e.getMessage());
		}

		return dto;
	}

	@RequestMapping(value = "/pki/encode", method = RequestMethod.POST)
	public ResultDTO encodePin(@RequestBody InputDTO inputDTO) {
		logger.debug("Inside encryptData()...encodePin =" + inputDTO);
		ResultDTO dto = null;
		try {
			ToolkitAssert.isNullorEmpty(inputDTO.getPin(), "Pin");
			ToolkitAssert.isNullorEmpty(inputDTO.getRequestHandle(), "RequestHandle");
			ToolkitAssert.isNullorEmpty(inputDTO.getPublicKey(), "publicKey");
			CryptoUtils cryptoUtils = new CryptoUtils();

			String base64EncodedPin = cryptoUtils.encryptParams(inputDTO.getPin(), inputDTO.getRequestHandle(),
					inputDTO.getPublicKey());

			dto = new ResultDTO();

			dto.setStatus(EnumStatus.SUCCESS);
			dto.setMessage(base64EncodedPin);

		} catch (Exception e) {
			throw new ToolkitException(e.getMessage());
		}

		return dto;
	}

}
