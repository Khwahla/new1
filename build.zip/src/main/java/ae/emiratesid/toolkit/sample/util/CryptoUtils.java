package ae.emiratesid.toolkit.sample.util;

import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import ae.emiratesid.toolkit.sample.exception.ToolkitException;

public class CryptoUtils {

	public String encryptData(String data, String pubKey) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException{

		if(data ==  null ){

		}//
		
		byte[] publickey = Base64.getDecoder().decode(pubKey);
		
		//get the byte array from string.
		byte[] plainData=  data.getBytes();
		
		//create a Chiper instance with PKCS1padding.
		Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");

		//Get the key
		PublicKey key = KeyFactory.getInstance("RSA")
				.generatePublic(new X509EncodedKeySpec(publickey));
		
		cipher.init(Cipher.PUBLIC_KEY, key);

		byte[] encryptedBytes = cipher.doFinal(plainData);
		System.out.println("Encryption done " + encryptedBytes.length);
		return Base64.getEncoder().encodeToString(encryptedBytes);
	}
	
	public String encryptData(byte[] data,byte[] publicKeyByte) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException{

		if(data ==  null ){

		}//

				
		//create a Chiper instance with PKCS1padding.
		Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");

		//Get the key
		PublicKey key = KeyFactory.getInstance("RSA")
				.generatePublic(new X509EncodedKeySpec(publicKeyByte));
	
		cipher.init(Cipher.PUBLIC_KEY, key);

		byte[] encryptedBytes = cipher.doFinal(data);
		System.out.println("Encryption done " + encryptedBytes.length);
		return Base64.getEncoder().encodeToString(encryptedBytes);
	}
	
	public String encryptDataSelfSigned(byte[] data, PublicKey key) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException{

		if(data ==  null ){

		}

		//create a Chiper instance with PKCS1padding.
		Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");

		cipher.init(Cipher.PUBLIC_KEY, key);

		byte[] encryptedBytes = cipher.doFinal(data);
		return Base64.getEncoder().encodeToString(encryptedBytes);
	}


	public String encryptParams(String param , String padding, String publicKey ) throws ToolkitException {

		byte[] paddingByte = Base64.getDecoder().decode(padding);
		byte[] paramsByte = param.getBytes();
		byte[] publicKeyByte = Base64.getDecoder().decode(publicKey);
		
		int totallength =  paddingByte.length + paramsByte.length;
		byte[] plainData =  new byte[totallength];
		
		
		System.arraycopy(paddingByte, 0, plainData, 0, paddingByte.length);
		System.arraycopy(paramsByte, 0, plainData, paddingByte.length , paramsByte.length);
		
		try {
			return encryptData(plainData,publicKeyByte);
		} catch (Exception e) {
			throw new ToolkitException(e);
		}
	}
	public String encryptParams(byte[] paramsByte , String requestHandle, String key) throws ToolkitException {
		
		byte[] paddingByte = Base64.getDecoder().decode(requestHandle);
		
		int totallength =  paddingByte.length + paramsByte.length;
		byte[] plainData =  new byte[totallength];
		
		System.arraycopy(paddingByte, 0, plainData, 0, paddingByte.length);
		System.arraycopy(paramsByte, 0, plainData, paddingByte.length , paramsByte.length);
		String str = new String(paddingByte) + new String(paramsByte);
		try {
			return encryptData(str, key);
		} catch (Exception e) {
			throw new ToolkitException(e);
		}
	}

	public byte[] encodePin(String pin) throws ToolkitException{
		
		if(pin == null || pin.isEmpty() || pin.length()<4 || pin.length() > 8){
			throw new ToolkitException("Invalid pin");
		}
		
		byte[] PIN =  pin.getBytes();
		
		byte[] encodedPin = new byte[8];
		
		byte[] convertedPin =  new byte[16];
		
		for (int iter = 0; iter < PIN.length; iter++) {
			convertedPin[iter] = (byte) (PIN[iter] - 0x30);
        }
		
		// Convert, copy & pad PIN data
		int i = 0;
        for ( ; i < PIN.length; i++) {
        	System.out.println("i ="+i+" : i % 2 ="+i % 2+": i/2 ="+i/2 );
            if (i % 2 != 0) {
                 encodedPin[i / 2] |=  (byte)(convertedPin[i]);
             }
            else {
            	encodedPin[i / 2] = (byte) ((convertedPin[i]) << 4);
             }
        }
  
		// Add padding for the odd counter
        if (i % 2 != 0) {
            encodedPin[i++ / 2] |= 0x0F;
        }
        
        // Pad the remaining buffer
        for (i = i / 2; i < 8; i++) {
        	encodedPin[i] = (byte) 0xFF;
        }
			
		return encodedPin;
	}
	
	public byte[] decrypt(PublicKey publicKey, byte [] encrypted) throws Exception {
		try {
			Cipher cipher = Cipher.getInstance("RSA");  
	        cipher.init(Cipher.DECRYPT_MODE, publicKey);
	        
	        return cipher.doFinal(encrypted);
		} catch (Exception e) {
			e.printStackTrace();
		}
        return null;
	}
	
	public byte[] decryptByPrivate(PrivateKey privateKey, byte [] encrypted) throws Exception {
		try {
			Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");  
	        cipher.init(Cipher.DECRYPT_MODE, privateKey);
	        
	        return cipher.doFinal(encrypted);
		} catch (Exception e) {
			e.printStackTrace();
		}
        return null;
	}
	
}
