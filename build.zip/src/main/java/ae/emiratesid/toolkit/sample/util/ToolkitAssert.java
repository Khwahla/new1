package ae.emiratesid.toolkit.sample.util;

import ae.emiratesid.toolkit.sample.exception.ToolkitException;

public abstract class ToolkitAssert {
	
	public static void isNullorEmpty(String paramValue, String paramName){
		if( null == paramValue || paramValue.isEmpty() ){
			throw new ToolkitException("Required parameter is empty:"+paramName);
		}
	}
}
