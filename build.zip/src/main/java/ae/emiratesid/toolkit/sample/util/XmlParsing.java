package ae.emiratesid.toolkit.sample.util;

import java.io.File;
import java.io.FileInputStream;
import java.security.Key;
import java.security.PublicKey;
import java.util.Iterator;

import javax.xml.crypto.AlgorithmMethod;
import javax.xml.crypto.KeySelector;
import javax.xml.crypto.KeySelectorException;
import javax.xml.crypto.KeySelectorResult;
import javax.xml.crypto.XMLCryptoContext;
import javax.xml.crypto.XMLStructure;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignatureMethod;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import sun.security.x509.X509CertImpl;

public class XmlParsing {


    public static void main(String[] args){
        parseVerifyPinXml();

        try {
            verifySignature();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//main


    public static void parseVerifyPinXml(){

        try {
            File inputFile = new File(Config.ROOT_DIR + "VerifyPIN.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
            NodeList nList = doc.getElementsByTagName("Body");
            System.out.println("----------------------------"+nList.getLength());
//            parseHeader(nList);
            parseBody(nList);
        } catch (Exception e) {
            e.printStackTrace();
        }//catch()

    }//parseVerifyPinXml()

    private static void parseBody(NodeList nList) {
        for (int temp = 0; temp < nList.getLength(); temp++) {
            Node nNode = nList.item(temp);
            System.out.println("\nCurrent Element :" + nNode.getNodeName());
            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) nNode;
                System.out.println("ResponseStatus : "
                        + eElement
                        .getElementsByTagName("ResponseStatus")
                        .item(0)
                        .getTextContent());
                System.out.println("MatchStatus : "
                        + eElement
                        .getElementsByTagName("MatchStatus")
                        .item(0)
                        .getTextContent());
            }

        }//for()
    }//parseBody()

    private static void parseHeader(NodeList nList) {

        for (int temp = 0; temp < nList.getLength(); temp++) {
            Node nNode = nList.item(temp);
            System.out.println("\nCurrent Element :" + nNode.getNodeName());

            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) nNode;
                System.out.println("RequestID : "
                        + eElement
                        .getElementsByTagName("RequestID")
                        .item(0)
                        .getTextContent());
                System.out.println("attempts_left : "
                        + eElement
                        .getElementsByTagName("attempts_left")
                        .item(0)
                        .getTextContent());
                System.out.println("status : "
                        + eElement
                        .getElementsByTagName("status")
                        .item(0)
                        .getTextContent());
                System.out.println("error_message : "
                        + eElement
                        .getElementsByTagName("error_message")
                        .item(0)
                        .getTextContent());
            }
        }

    }//parseHeader()


    public static boolean verifySignature() throws Exception {

        File inputFile = new File(Config.ROOT_DIR + "VerifyPIN.xml");
        // Instantiate the document to be validated
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        Document doc = dbf.newDocumentBuilder().parse(
                new FileInputStream(inputFile));

        // Find Signature element
        NodeList nl = doc.getElementsByTagNameNS(XMLSignature.XMLNS,
                "Signature");
        if (nl.getLength() == 0) {
            throw new Exception("Cannot find Signature element");
        }

        // Create a DOM XMLSignatureFactory that will be used to unmarshal the
        // document containing the XMLSignature
        XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM");

        // Create a DOMValidateContext and specify a KeyValue KeySelector
        // and document context
        DOMValidateContext valContext = new DOMValidateContext(
                new X509KeySelector(), nl.item(0));

        // unmarshal the XMLSignature
        XMLSignature signature = fac.unmarshalXMLSignature(valContext);

        // Validate the XMLSignature (generated above)
        boolean coreValidity = signature.validate(valContext);

        // Check core validation status
        if (coreValidity == false) {
            System.err.println("Signature failed core validation");
            boolean sv = signature.getSignatureValue().validate(valContext);
            System.out.println("signature validation status: " + sv);
            // check the validation status of each Reference
            Iterator<?> i = signature.getSignedInfo().getReferences().iterator();
            for (int j = 0; i.hasNext(); j++) {
                boolean refValid = ((Reference) i.next()).validate(valContext);
                System.out.println("ref[" + j + "] validity status: "
                        + refValid);
            }
        } else {
            System.out.println("Signature passed core validation");
        }
       return false;
    }//


    private static class X509KeySelector extends KeySelector {
        public KeySelectorResult select(KeyInfo keyInfo,
                                        KeySelector.Purpose purpose,
                                        AlgorithmMethod method,
                                        XMLCryptoContext context)
                throws KeySelectorException {
            Iterator ki = keyInfo.getContent().iterator();
            while (ki.hasNext()) {
                XMLStructure info = (XMLStructure) ki.next();
                if (!(info instanceof X509Data)) {
                    System.out.println("Not an instance of X509Data");
                continue;
                }//if()

                X509Data x509Data = (X509Data) info;
                Iterator xi = x509Data.getContent().iterator();
                System.out.println(" XI length " + x509Data.getContent().size());
                while (xi.hasNext()) {
                    System.out.println("Xi is iterating.");
                    Object o = xi.next();
                    if (!(o instanceof X509CertImpl)) {
                        System.out.println("Class " + o.getClass().toString());
                        continue;
                    }
                    final PublicKey key = ((X509CertImpl)o).getPublicKey();
                    System.out.println("Issuer Name" + ((X509CertImpl)o).getIssuerDN());
                    // Make sure the algorithm is compatible
                    // with the method.
                    System.out.println("public key found");
                    System.out.println("method Algorithm " + method.getAlgorithm());
                    System.out.println("key  Algorithm " +key.getAlgorithm());
                    if (algEquals(method.getAlgorithm(), key.getAlgorithm())) {
                        return new KeySelectorResult() {
                            public Key getKey() { return key; }
                        };
                    }
                }
            }
            throw new KeySelectorException("No key found!");
        }

        boolean algEquals(String algURI, String algName) {
            if ((algName.equalsIgnoreCase("DSA") &&
                    algURI.equalsIgnoreCase(SignatureMethod.DSA_SHA1)) ||
                    (algName.equalsIgnoreCase("RSA") &&
                            algURI.equalsIgnoreCase(SignatureMethod.RSA_SHA1))) {
                return false;
            } else {
                return true;
            }
        }
    }
    
}//end of class
