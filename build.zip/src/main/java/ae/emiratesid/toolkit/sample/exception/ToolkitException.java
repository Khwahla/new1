package ae.emiratesid.toolkit.sample.exception;

/**
 * <h1>ToolkitException</h1>
 * This class defines ToolkitException
 *
 * @version 1.0
 * @since 1.8
 *
 */
public class ToolkitException extends RuntimeException {

	private long code = ErrorCodes.E_UNSPECIFIED_ERROR;

	/**
	 * Constructor to initialize exception with message
	 * 
	 * @param message ToolkitException class is initialized with the given
	 * message
	 */
	public ToolkitException(String message) {
		super(message);
	}

	/**
	 * Constructor to initialize exception with actual exception
	 * 
	 * @param ex ToolkitException class is initialized with the given
	 * ex
	 */
	public ToolkitException(Exception ex) {
		super(ex);
	}

	/**
	 * Constructor to initialize exception with message and code
	 * 
	 * @param message error message to set
	 * @param code error code to set
	 */
	public ToolkitException(String message, long code) {
		super(message);
		this.code = code;
	}

	/**
	 * Constructor to initialize exception with code
	 * 
	 * @param code error code to set
	 */
	public ToolkitException(long code) {
		this(ErrorCodes.getErrorMessage(code), code);
	}

	/**
	 * This method is used to get the error code
	 * 
	 * @return long error code
	 */
	public long getCode() {
		return this.code;
	}

	/**
	 *  This method is used to set the error code
	 * 
	 * @param code error code to set
	 */
	public void setCode(long code) {
		this.code = code;
	}

}
