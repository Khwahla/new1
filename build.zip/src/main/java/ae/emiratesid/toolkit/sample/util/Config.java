package ae.emiratesid.toolkit.sample.util;

public class Config {

    public static final String ROOT_DIR = "/";
    public static final String VG_URL = "http://0030ca42.ngrok.io/ValidationGatewayService";
    public static final boolean isNFC = false;
    public static final String ROOT_DSS_DIR = "E:/saurabh_pc_back_up/Saurabh/workspace_1/EIDACardSDK/src/main/resources/dss/" ;
}
