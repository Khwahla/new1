package ae.emiratesid.toolkit.sample.exception;

import java.util.Hashtable;

/**
 * <h1>ErrorCodes</h1>
 * This class defines all the error codes and messages used 
 * in the EIDATookit SDK
 * @version 1.0
 * @since 1.8
 *
 */
public class ErrorCodes {

	public static int E_UNSPECIFIED_ERROR		 = 1000;

	public static int E_NULL_ARGUMENT			 = 100;
	public static int E_INVALID_ARGUMENT_VALUE	 = 101;
	public static int E_NO_LIBS_TO_LOAD			 = 102;
	public static int E_READER_NOT_CONNECTED	 = 103;
	public static int E_SIGN_DATA_FAILED		 = 104;

	public static int E_LIB_LOADING_FAILED = 112;





	private static final Hashtable<Integer, String> messages = new Hashtable();

	// initialize the error map
	static {
		messages.put(Integer.valueOf(E_NULL_ARGUMENT), "Null/Empty argument provided");
		messages.put(Integer.valueOf(E_INVALID_ARGUMENT_VALUE), "Invalid argument provided");
		messages.put(Integer.valueOf(E_UNSPECIFIED_ERROR), "Unspecified Error");
		messages.put(Integer.valueOf(E_NO_LIBS_TO_LOAD), "No libs found to load");
		messages.put(Integer.valueOf(E_READER_NOT_CONNECTED), "Not Connected");
		messages.put(Integer.valueOf(E_SIGN_DATA_FAILED), "Data signing failed");

	}

	/**
	 * This method is to get ToolkitException
	 * @param code error code to set
	 * @return ToolkitException with the specified error code
	 */
	public static ToolkitException getMiddlewareException(int code) {
		return new ToolkitException(getErrorMessage(code), code);
	}

	
	/**
	 * This method is to get error message associated with 
	 * given error code 
	 * @param code error code whose error message is returned
	 * @return String error message
	 */
	public static String getErrorMessage(long code) {

		String errorMessage = messages.get(Integer.valueOf((int) code));
		if (errorMessage != null) {
			return errorMessage;
		}
		return "UNKNOWN EXCEPTION";
	}

}
