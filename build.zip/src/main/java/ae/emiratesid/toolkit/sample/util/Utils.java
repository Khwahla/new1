package ae.emiratesid.toolkit.sample.util;

import java.io.FileOutputStream;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;

/**
 * <h1>Utils</h1>
 * This class defines all the utility methods useful for SDK integration.
 *  
 * 
 * @version 1.0
 * @since 1.6
 * 
 */
public class Utils {

	static char hexval[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
	
	
	/**
	 * This method is to convert byte array data to String
	 * 
	 * Returns null if byteData is null/empty
	 * 
	 * @param byteData data to convert.
	 * @return String converted data
	 */
	public static String convertByteToString( byte[] byteData ){
		
		if( null != byteData && 0 < byteData.length ){
			return new String( byteData ).replaceAll("\\p{C}", " ").trim();
		}// if()
		
		return null;
		
	}	
	
	
	/**
	 * This method is to convert byte array data to String
	 * 
	 * Returns null if byteData is null/empty
	 * 
	 * @param byteData data to convert.
	 * @param processMode the mode in which service is running. 
	 * 	true : in-process mode
	 * 	false : agent mode
	 * 
	 * @return String converted data
	 */
	public static String convertByteToString( byte[] byteData, boolean processMode ){
		
		if( null != byteData && 0 < byteData.length ){
			if( processMode )		
				return new String( byteData ).replaceAll("\\p{C}", " ").trim();
			else
				return new String( byteData );			
		}
		
		return null;
		
	}
	
	
	
	
	/**
	 * This method is to convert byte array data to String
	 * with specified encoding
	 * 
	 * Returns null if byteData is null/empty
	 * 
	 * @param byteData data to convert.
	 * @return String converted data
	 */
	public static String convertByteToStringUTF( byte[] byteData, 
						String encoding ) {
		try {
			
			if( null != byteData && 0 < byteData.length ){
				return new String( byteData, encoding ).replaceAll("\\p{C}", " ").trim();
			}			
			
		} catch (Exception e) {

		}
		
		return null;
		
	}
	
	
	/**
	 * This method is to convert byte array data to String
	 * with specified encoding
	 * 
	 * Returns null if byteData is null/empty
	 * 
	 * @param byteData data to convert.
	 * @param processMode the mode in which service is running. 
	 * 	true : in-process mode
	 * 	false : agent mode
	 * @return String converted data
	 */
	public static String convertByteToStringUTF( byte[] byteData, 
						String encoding, boolean processMode ) {
		try {
			
			if( null != byteData && 0 < byteData.length ){
				if( processMode )
					return new String( byteData, encoding ).replaceAll("\\p{C}", " ").trim();
				else
					return new String( byteData, encoding );
			}		
			
		} catch (Exception e) {

		}
		
		return null;
		
	}
	
	
	/**
	 * This method is to write array of bytes to a file.
	 * @param data byte data to be written into file
	 * @param fileName file name with file path and extension
	 * @throws Exception if any error occures while writing file
	 */
	public static void writeImageFile( byte[] data, String fileName ) 
															throws Exception{
		// if byte data is empty then return
		if( null == data || 0 == data.length )
			return;
		
		//convert array of bytes into file
	    FileOutputStream fileOuputStream =
                  new FileOutputStream( fileName );
	    fileOuputStream.write(data);
	    fileOuputStream.close();
		
	}
	
	
    /**
     * This method is to convert byte array to hex string (Uppser case)
     * @param arrayBytes to be converted
     * @return string converted string
     */
    public static String convertByteArrayToHexString(byte[] arrayBytes) {
    	
    	// if byte data is empty then return
		if( null == arrayBytes || 0 == arrayBytes.length )
			return null;
    	
        StringBuffer stringBuffer = new StringBuffer();
        for (int i = 0; i < arrayBytes.length; i++) {
            stringBuffer.append(Integer.toString(
                    (arrayBytes[i] & 0xff) + 0x100, 16)
                    .substring(1));
        }
        return stringBuffer.toString();
    }
    
    
    /**
     * This method is to convert byte array to hex string (Uppser case)
     * @param arrayBytes to be converted
     * @param processMode the mode in which service is running. 
	 * 	true : in-process mode
	 * 	false : agent mode
	 *
     * @return string converted string
     */
    public static String convertByteArrayToHexString(byte[] arrayBytes, boolean processMode) {
    	
    	// if byte data is empty then return
		if( null == arrayBytes || 0 == arrayBytes.length )
			return null;
    	
		if( !processMode )
			return new String( arrayBytes );		
		
        StringBuffer stringBuffer = new StringBuffer();
        for (int i = 0; i < arrayBytes.length; i++) {
            stringBuffer.append(Integer.toString(
                    (arrayBytes[i] & 0xff) + 0x100, 16)
                    .substring(1));
        }
        return stringBuffer.toString();
    }
	
    
    /**
     * This method is to convert byte array into hexadecimal string with provided delimiter
     * 
     * @param data byte array to be converted
     * @param delimiter bytes delimiter
     * @return String converted hex string
     */
    public static String byteArrayToHexString(byte[] data, String delimiter)
    {
        if( data == null || 0 == data.length )
            return null;

        StringBuffer strBuff = new StringBuffer();

        for( int i=0; i<data.length; i++ ){
        	strBuff.append((char)hexval[((data[i] >> 4) & 0x0F)]);
        	strBuff.append((char)hexval[(data[i]) & 0x0F]);

            if(delimiter!=null && i<data.length-1)
            	strBuff.append(delimiter);
        }

        return strBuff.toString();
    }
    
    
    /**
     * This method is used to compute SHA1 hash of a given data.
     * @param data to be hashed
     * 
     * @return byte[] hashed data.
     * 
     * @throws Exception if any error occurred while hash computation.
     */
    public static byte[] computeSHA1Hash( String data ) throws Exception{
    	
    	try {
			
    		// validate the input
    		if( null == data || data.isEmpty() )
    			return null;
    		
    		
    		MessageDigest messageDigest = MessageDigest.getInstance( "SHA1" );
    		messageDigest.update( data.getBytes() );
    		return messageDigest.digest();
    		
		} catch (Exception e) {
			throw e;
		}
    	    	
    }
    /**
     * This method is used to compute SHA256 hash of a given data.
     * @param data to be hashed
     * 
     * @return byte[] hashed data.
     * 
     * @throws Exception if any error occurred while hash computation.
     */
    public static byte[] computeSHA256Hash( String data ) throws Exception{
    	
    	try {
			
    		// validate the input
    		if( null == data || data.isEmpty() )
    			return null;
    		
    		
    		MessageDigest messageDigest = MessageDigest.getInstance( "SHA-256" );
    		messageDigest.update( data.getBytes() );
    		return messageDigest.digest();
    		
		} catch (Exception e) {
			throw e;
		}
    	    	
    }
    
    // computeSHA1Hash()
    public static String convertByteArrayToString(byte[] data){
		if(null == data ){
			return null;
		}
		try {
			return new String(data , "UTF-8");
		} catch (UnsupportedEncodingException e) {
			return null;
		}
	}
    
    public static void main(String[] args) {
		System.out.println("in main");
		String dataStr = "MIIHQgYJKoZIhvcNAQcCoIIHMzCCBy8CAQExDzANBglghkgBZQMEAgEFADALBgkqhkiG9w0BBwGgggObMIIDlzCCAn+gAwIBAgIQC/EueRJHWjD5Z2D1qwmT/TANBgkqhkiG9w0BAQsFADB/MTUwMwYDVQQDDCxDaXRpemVuIGFuZCBSZXNpZGVudCBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTEOMAwGA1UECwwFUFJJREMxHTAbBgNVBAoMFE1pbmlzdHJ5IG9mIEludGVyaW9yMQswCQYDVQQGEwJBRTEKMAgGA1UEBAwBNjAeFw0xNzAyMDIwNzM4MjdaFw0yMDAxMDExMjAwMDBaMEkxCzAJBgNVBAYTAklOMSIwIAYDVQQFExk3ODQxOTg5Njg2MDYzOTYvMDAwMDEzOTQyMRYwFAYDVQQDDA1Eb3RpIE5hcmVzaCAgMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA88a35dtMVNAH/FdwXRrCRonrFXzmQckE/niXxTwi26du3kTkm5jI/ojNCOzMQpq8bVcqLYQewOIErDZ5RItMMpjD5ZuF+cjseBU1U4TJ3ZecCOq2AjpnQAn8ZhygwStaquHKS7gjA2EvkhYMMoFC7i8tV1S5ZOygkybbwxN8dCddvSXRqfP8/+QarmhoDkDtsABa8VSDawGnZKRQBL+V5K0H2je+LfJrQVWQk2nt14OYHjIylsSz2CquA5y2g/V9+LZe44WxfsfSHnOobdpwtbm4RGwbF24sLHrwTohogFz2rSTzWEY+f33zgpWtgoysHrMe7GDciB+8QhYkdjSOdwIDAQABo0UwQzAfBgNVHSMEGDAWgBTMWrXWyxTTohY8iX8wN+0P2MqaUzALBgNVHQ8EBAMCA6gwEwYDVR0lBAwwCgYIKwYBBQUHAwIwDQYJKoZIhvcNAQELBQADggEBAFYxlXr3dstFdKTirrjiLOGH7HyRBA84DC8nJ/PxuriK1MzKTMvB7J4k7WEEz9DXblW4PhuZsRSSSxItVLGitq1JCnhVFDkBRfX137ZQXn27wRPCLanGeCV66a4BFi6EoQhhu7jn6tbaV4BIGzhCSSja+p85F3jOIYnuFXodcLliDpCGzo86thojUrzW/Df6fdWhoswlHU2rNSGPmcXsqACC9lqSxiOlqcSzA6HYBZguOabxImmUoSZDPvm3p/IV9rRElf2AF7EPFB1N6cvNkA7P3TzfM3oMMUGylsuNo6CmBZ00T+eowVV7SXoAilCBQPMoBht1JEai6fVQmQpMVk4xggNrMIIDZwIBATCBkzB/MTUwMwYDVQQDDCxDaXRpemVuIGFuZCBSZXNpZGVudCBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTEOMAwGA1UECwwFUFJJREMxHTAbBgNVBAoMFE1pbmlzdHJ5IG9mIEludGVyaW9yMQswCQYDVQQGEwJBRTEKMAgGA1UEBAwBNgIQC/EueRJHWjD5Z2D1qwmT/TANBglghkgBZQMEAgEFAKCCAagwGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTcxMjI2MTExNjM5WjAlBgsqhkiG9w0BCRACETEWMBSgBwwFSW5kaWGhBQwDaHlkogIwADAtBgkqhkiG9w0BCTQxIDAeMA0GCWCGSAFlAwQCAQUAoQ0GCSqGSIb3DQEBCwUAMC8GCSqGSIb3DQEJBDEiBCA6LFxJ25o1+uyj4hFhCge6mWtqjvdK7iUTkslaVVfZWzCB5gYLKoZIhvcNAQkQAi8xgdYwgdMwgdAwgc0wDQYJYIZIAWUDBAIBBQAEILu1uM8ha4SfIGcspEXr9Rc1PJwTgwEkM0yBM9L4llABMIGZMIGEpIGBMH8xNTAzBgNVBAMMLENpdGl6ZW4gYW5kIFJlc2lkZW50IENlcnRpZmljYXRpb24gQXV0aG9yaXR5MQ4wDAYDVQQLDAVQUklEQzEdMBsGA1UECgwUTWluaXN0cnkgb2YgSW50ZXJpb3IxCzAJBgNVBAYTAkFFMQowCAYDVQQEDAE2AhAL8S55EkdaMPlnYPWrCZP9MA0GCSqGSIb3DQEBCwUABIIBAGhBB86mGkaYEEmuq5L7h63jJzOdabOYmgQh9VSox5eFTl3aKwi7ArKfU8o9CaKdISMe5gbybBFF15tBhELcshyLIrK1FnHyGWbF/3tXLBrWekjupIYRnJLKorDlBk/ukuIWXvRh/WYVBZXrJWPUg6kEUm+R7EHkdI/3gYUgX8Xt98WsdOvEF88FdJJFrCyrc1VeDJxYpGMAMyX6rY6+XfBDGemmjClAiS1+EidmFJpzlRedWNvvHAH/XZggTrAk1+oj2EI4oxm1UErt2e4x5RHOKV7pR0Xy83ZR09fhGPdTk/NY3d0cKw2X8ii+kAv2Q8c7/OqAOjuPozNz7Us0dR8=";
		
		try {
			FileUtils.writeFile("E:\\somu1.txt", Base64.decode(dataStr));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}   
    
}
